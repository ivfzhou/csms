sc create KMDFDriver binPath=%cd%\KMDFDriver.sys start=system error=ignore type=kernel DisplayName=KMDFDriver
sc start KMDFDriver
